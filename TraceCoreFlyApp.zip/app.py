from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

app = FastAPI()
memory_store = {}

@app.get("/memory/get")
async def get_memory(key: str):
    value = memory_store.get(key)
    return {"key": key, "value": value}

@app.post("/memory/set")
async def set_memory(request: Request):
    data = await request.json()
    key = data.get("key")
    value = data.get("value")
    if key and value is not None:
        memory_store[key] = value
        return {"status": "success", "key": key}
    return JSONResponse(status_code=400, content={"error": "Missing key or value"})
