from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel
from typing import Optional
from supabase import create_client, Client
import os

app = FastAPI()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
AUTH_TOKEN = os.getenv("TRACECORE_AUTH_TOKEN")

if not SUPABASE_URL or not SUPABASE_KEY or not AUTH_TOKEN:
    raise Exception("Missing required environment variables.")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

class MemoryPayload(BaseModel):
    key: str
    value: dict
    tags: Optional[list[str]] = []

def verify_token(token: str):
    if token != AUTH_TOKEN:
        raise HTTPException(status_code=403, detail="Invalid token.")

@app.get("/memory/get")
def get_memory(key: str, token: str = Header(...)):
    verify_token(token)
    result = supabase.table("memory").select("*").eq("key", key).execute()
    if result.data:
        return result.data[0]
    raise HTTPException(status_code=404, detail="Memory key not found.")

@app.post("/memory/set")
def set_memory(payload: MemoryPayload, token: str = Header(...)):
    verify_token(token)
    existing = supabase.table("memory").select("*").eq("key", payload.key).execute()
    if existing.data:
        supabase.table("memory").update({
            "value": payload.value,
            "tags": payload.tags
        }).eq("key", payload.key).execute()
    else:
        supabase.table("memory").insert({
            "key": payload.key,
            "value": payload.value,
            "tags": payload.tags
        }).execute()
    return {"status": "success", "key": payload.key}

@app.delete("/memory/delete")
def delete_memory(key: str, token: str = Header(...)):
    verify_token(token)
    supabase.table("memory").delete().eq("key", key).execute()
    return {"status": "deleted", "key": key}
